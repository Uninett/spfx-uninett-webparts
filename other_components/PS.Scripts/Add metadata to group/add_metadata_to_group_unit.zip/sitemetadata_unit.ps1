﻿param (
  [Parameter(Mandatory=$True)]
  [string]$tenant,
  
  [Parameter(Mandatory=$True)]
  [string]$path,
  
  [Parameter(Mandatory=$True)]
  [string]$id
)

Function Authenticate {
    # this is the path to the Microsoft.IdentityModel.Clients.ActiveDirectory.dll on my environment. Ensure that you have the proper path set
    Add-Type -Path 'C:\Program Files\WindowsPowerShell\Modules\AzureAD\2.0.1.10\Microsoft.IdentityModel.Clients.ActiveDirectory.dll'
    $tenantID = "20add3ee-edc6-4563-a6d6-ddc40b33caf3"
    $authString = "https://login.microsoftonline.com/$tenantID" 

    $appId = "4aedc18c-5699-4ce3-8df3-55223872cd62"
    $appSecret = "pckDKWV991@{nvozQTW82!?"

    # this part uses the classes to obtain the necessary security token for performing our operations against the Graph API
    $creds = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.ClientCredential" -ArgumentList $appId, $appSecret
    $authContext = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContext"-ArgumentList $authString
    $context = $authContext.AcquireTokenAsync("https://graph.microsoft.com/", $creds).Result

    return $context
}

$token = Authenticate

$authHeader = @{
   'Content-Type'='application\json'
   'Authorization'=$token.CreateAuthorizationHeader()
}

$uri = "https://graph.microsoft.com/v1.0/groups/"+$id

$file = Get-Content -Raw -Path $path
            
Invoke-RestMethod -Uri $uri -Headers $authHeader -Method Patch -ContentType "application/json" -Body $file


   